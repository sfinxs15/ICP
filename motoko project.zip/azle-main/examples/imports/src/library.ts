export function one() {
    return 'one';
}

export function two() {
    return 'two';
}

export function three() {
    return 'three';
}
