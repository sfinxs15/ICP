import type { Principal } from '@dfinity/principal';
export interface _SERVICE {
    getInitialized: () => Promise<boolean>;
}
