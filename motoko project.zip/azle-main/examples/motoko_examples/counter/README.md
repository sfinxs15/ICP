# Counter

Reimplementation of the [Motoko Counter example](https://github.com/dfinity/examples/tree/master/motoko/counter)
