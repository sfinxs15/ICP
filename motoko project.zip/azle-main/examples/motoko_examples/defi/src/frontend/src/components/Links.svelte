<p>
  Visit the <a href="https://smartcontracts.org">Internet Computer SDK</a> to learn
  how to build canister smart contracts.
</p>
