<div>
  <p>Backend canister ID: {process.env.DEFI_DAPP_CANISTER_ID}</p>
  <p>Frontend canister ID: {process.env.FRONTEND_CANISTER_ID}</p>
  <p>
    Internet Identity canister ID: {process.env.INTERNET_IDENTITY_CANISTER_ID}
  </p>
</div>

<style>
  p {
    color: #666;
    font-size: 14px;
    margin: 0 0 8px;
  }
  div {
    margin-top: 40px;
  }
</style>
