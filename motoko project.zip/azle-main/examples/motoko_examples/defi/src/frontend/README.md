# Defi Frontend

The frontend uses svelte and is based on the dfinity svelte [templates](https://github.com/dfinity/examples/tree/master/svelte-motoko-starter).
