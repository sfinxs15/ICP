cd motoko
dfx build
cd ../factory
dfx build
