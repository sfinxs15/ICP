# Http Counter

Reimplementation of the [Motoko Http Counter example](https://github.com/dfinity/examples/tree/master/motoko/http_counter)
