# Minimalistic Dapp

Reimplementation of the [Motoko Minimalistic Dapp example](https://github.com/dfinity/examples/tree/master/motoko/minimal-counter-dapp)
