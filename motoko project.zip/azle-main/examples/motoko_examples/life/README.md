# Game of Life and Upgrades Example

Reimplementation of the [Motoko Game of Life and Upgrades Example](https://github.com/dfinity/examples/tree/master/motoko/life)
