# Motoko Examples

These examples are clones of [DFINITY's Motoko examples](https://github.com/dfinity/examples/tree/master/motoko).
