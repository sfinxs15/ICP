import { Query } from 'azle';

// Say the given phrase.
export function say(phrase: string): Query<string> {
    return phrase;
}
