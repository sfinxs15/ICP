# Persistent storage

Reimplementation of the [Motoko Persistent storage example](https://github.com/dfinity/examples/tree/master/motoko/persistent-storage)
