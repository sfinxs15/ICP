# Factorial

Reimplementation of the [Motoko Factorial example](https://github.com/dfinity/examples/tree/master/motoko/factorial)
