# Calc

Reimplementation of the [Motoko Calc example](https://github.com/dfinity/examples/tree/master/motoko/calc)
