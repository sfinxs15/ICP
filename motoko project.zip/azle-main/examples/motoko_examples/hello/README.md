# Hello

Reimplementation of the [Motoko Hello example](https://github.com/dfinity/examples/tree/master/motoko/hello)
