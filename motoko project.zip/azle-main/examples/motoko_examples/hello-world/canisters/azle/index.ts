import { Query } from 'azle';

export function main(): Query<void> {
    console.log('Hello World!');
}
