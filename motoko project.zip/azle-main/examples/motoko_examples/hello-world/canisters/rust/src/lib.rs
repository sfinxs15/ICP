#[ic_cdk_macros::query]
pub fn main() -> () {
    ic_cdk::println!("Hello World");
}