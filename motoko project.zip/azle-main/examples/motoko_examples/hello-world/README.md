# Hello World

Reimplementation of the [Motoko Hello World example](https://github.com/dfinity/examples/tree/master/motoko/hello-world)
