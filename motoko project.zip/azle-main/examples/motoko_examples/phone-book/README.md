# Phone book

Reimplementation of the [Motoko Phone book example](https://github.com/dfinity/examples/tree/master/motoko/phone-book)
